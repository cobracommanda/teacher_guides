function theOrganizer(){
	$('div.content-focus').insertBefore('div.objectives');
}